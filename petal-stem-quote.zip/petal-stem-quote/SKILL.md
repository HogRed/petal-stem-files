---
name: petal-stem-quote
description: Write a wedding or event flower quote in Petal & Stem's format. Use whenever Dana asks for a quote, an estimate, or a proposal for a wedding, funeral, or event.
---

# Petal & Stem wedding and event quotes

This is how Dana prices and writes a quote. Follow it every time.

## How to price it

1. **Flowers: three times what they cost me.** If the stems for an
   arrangement cost $18, the arrangement is $54. My costs are in
   `wedding pricing scratch.txt` if you have it; ask me if you don't.
2. **Labor is separate, at $35 an hour.** Never fold labor into the flower
   price — I want to see it, and so does the customer.
3. **Delivery and setup gets its own line.** Always. Even when it's small,
   even when I'm tempted to throw it in.
4. **Anything they asked to see priced separately stays separate.** If
   somebody asks about an arch, it's its own line, not bundled into the
   ceremony total.

## What every quote has to include

- A line for each piece, with the quantity, so they can take something out
  without asking me to redo the whole thing
- Labor as its own line with the hours shown
- Delivery and setup as its own line, with both addresses if there are two
- A total
- **"This quote is good for 30 days."**
- **"A 50% deposit holds the date."**

## How it should sound

Warm and plain, the way I'd say it standing at the counter. Not corporate.
Short sentences. No "bespoke," no "luxury," no "curated."

Open by referring to something they actually told me — their colors, their
venue, the thing they were excited about. Two sentences of that, then the
numbers.

## Format

```
Quote for [NAME] — [EVENT], [DATE]

[Two warm sentences that mention something specific they told me.]

  Bridal bouquet                              1        $  ---
  Bridesmaid bouquets                         6        $  ---
  Boutonnieres                                8        $  ---
  Corsages                                    2        $  ---
  Centerpieces                               12        $  ---
  Head table arrangement                      1        $  ---
  Church door arrangements                    2        $  ---

  Labor — [N] hours at $35/hr                          $  ---
  Delivery and setup — [venue 1] and [venue 2]         $  ---

  TOTAL                                                $  ---

This quote is good for 30 days.
A 50% deposit holds the date.

[One closing line inviting them to change anything.]
```

## When something's missing

If I haven't told you the guest count, the venue, or the date, **ask me**.
Don't guess and don't put a placeholder in a quote I might send.
