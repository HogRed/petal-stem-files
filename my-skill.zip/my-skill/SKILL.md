---
name: my-skill
description: [ONE SENTENCE. What this does, then when Claude should use it. Include the words you'd actually say when you want this job done. Under 200 characters.]
---

# [THE JOB, in a few words]

[One or two sentences: what this job is, and anything Claude needs to know
before it starts.]

## My rules

[Three to six rules. These are the things nobody else would guess — your
prices, your markup, the lines you always include, the words you never use.
This section is the whole reason the skill is worth having.]

1. [Rule]
2. [Rule]
3. [Rule]
4. [Rule]

## What the finished thing has to include

- [Something that must always be there]
- [Something that must always be there]
- [The line you always forget]

## How it should sound

[Warm? Plain? Formal? Write one sentence the way you'd actually say it out
loud, and put it here as an example.]

## When something's missing

If you don't have [the thing you always end up having to supply], ask me
instead of guessing.
